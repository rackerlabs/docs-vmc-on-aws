==========================================
Additional resources for vRealize Business
==========================================

The following resources are recommended for vRealize Business:

- `VMware Hands on Lab: HOL-1701-USE-2 vRealize Operations and vRealize
  Business - Optimize Compute Utilization
  <http://labs.hol.vmware.com/HOL/catalogs/catalog/123>`_

- `Official VMware vRB Documentation
  <http://pubs.vmware.com/vRBforCloud-701/index.jsp>`_
