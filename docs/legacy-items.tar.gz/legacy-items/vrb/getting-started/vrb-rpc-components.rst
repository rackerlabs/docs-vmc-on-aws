
vRealize Business components
----------------------------

The vRealize Business add-on product consists of a single virtual appliance
deployed to the management resource pool. The vRealize Business appliance
provides all of the functionality of vRealize Business. Both the vRealize
Automation™ appliance and the vCenter Server® are registered with vRealize
Business. You can access vRealize Business by using the Business Management tab
in the vRealize Automation web interface.
