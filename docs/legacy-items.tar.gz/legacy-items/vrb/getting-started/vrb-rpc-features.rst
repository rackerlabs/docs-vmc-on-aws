
vRealize Business features
--------------------------

This section lists the features of the product that are available for
your use within the RPC-VMware environment and your customer permissions.
Features not listed here either need to be performed by Rackspace
(see the :ref:`vRealize Business managed services section
<vrb-managed-services>`) or might be unavailable within the RPC-VMware
product and its add-on services.

Following are the major features of the vRealize Business add-on product:

- Automatic private cloud metering, costing, and pricing

- Private cloud consumption analysis

- Private cloud and public cloud cost comparison

- Out-of-the-box hybrid cloud assessment (comprehensive cloud costing
  and business assessment)

- Automatic reporting and API for data extraction

- Data center optimization (integrated with VMware vRealize Operations™)

- Identifying private cloud reclamation opportunities (integrated with
  vRealize Operations)

- Public cloud costing, consumption analysis, and pricing

- Role-based showback

- Quantifying private cloud reclamation opportunities (integrated with
  vRealize Operations)

- Automatic service catalog pricing (integrated with vRealize
  Automation)

- Custom reporting
