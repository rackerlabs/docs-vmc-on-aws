
vRealize Business architecture
------------------------------

The following diagram shows the architecture of the vRealize Business
add-on product in the RPC-VMware environment. The vRealize Business
components are explained in the next section.

.. figure:: ../../figures/vrb-rpc-architecture-1.png
   :alt: vRB architecture diagram
