
vRealize Business authentication methods
----------------------------------------

Because you access vRealize Business via the vRealize Automation web
interface, it shares the same authentication method as vRealize
Automation. The vRealize Authomation add-on feature might be configured
to use Rackspace hosted Active Directory (intensive.int) or a
customer-maintained Active Directory, in a similar manner as RPC-VMware.

For details, see the `vRealize Automation authentication methods
<https://developer.rackspace.com/docs/rpc-vmware/rpc-vmware-customer-handbook/vra/getting-started/vra-vpc-authentication/>`_
and the `RPC-VMware authentication methods
<https://developer.rackspace.com/docs/rpc-vmware/rpc-vmware-customer-handbook/rpcv-getting-started/#rpc-vmware-authentication-methods>`_.
