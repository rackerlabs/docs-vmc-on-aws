
vRealize Business roles and permissions
---------------------------------------

To implement the separation of customer and Rackspace duties
in vRealize Business, Rackspace implements vRealize Business roles.

Rackspace users are assigned the Business Management Administrator role.
The user with this role has permissions to perform the updates in vRealize
Business. However, the user must have the Tenant Administrator role
from vRealize Automation to add endpoints into vRealize Business.

Customer users are assigned the following vRealize Business roles:

- Business Management Administrator: The user has permissions to
  perform the updates in vRealize Business. However, the
  user must have the Tenant Administrator role from vRealize
  Automation to add endpoints into vRealize Business.

- Business Management Controller: Typically a line-of-business
  administrator, business manager, or IT administrator who is
  responsible for a tenant. Users with this role are
  responsible for user and group management, tenant branding and
  notifications, and business policies such as approvals and
  entitlements. They also track resource usage by all users within the
  tenant and initiate reclamation requests for VMs.
