=====================================================
Getting started with vRealize Business for RPC-VMware
=====================================================

This section provides the following information about the vRealize Business
add-on for Rackspace Private Cloud powered by VMware (RPC-VMware):

.. toctree::
   :maxdepth: 1

   vrb-rpc-architecture.rst
   vrb-rpc-components.rst
   vrb-rpc-features.rst
   vrb-rpc-roles.rst
   vrb-rpc-managed.rst
   vrb-rpc-spheres-support.rst
   vrb-rpc-compatibility.rst
   vrb-rpc-authentication.rst
