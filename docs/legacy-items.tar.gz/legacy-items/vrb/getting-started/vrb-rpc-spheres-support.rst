
vRealize Business spheres of support
------------------------------------

Rackspace installs vRealize Business, performs initial configuration,
and registers vRealize Automation with vRealize Business.

Rackspace completely manages and supports the vRealize Business appliance.
Rackspace is responsible for keeping the vRealize Business appliance up
and running, and for backing up and restoring it as needed.
Rackspace configures and responds to monitoring for the vRealize Business
appliance.

Customers are responsible for configuring and using features within
vRealize Business, such as expenses, consumption, and reports. The customer
monitors the progress of tasks, such as report execution.
