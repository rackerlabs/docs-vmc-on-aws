.. _vrb-managed-services:

vRealize Business managed services
----------------------------------

Rackspace provides support to keep the vRealize Business appliance available
and functioning correctly.

Rackspace is not responsible configuring features, such as reports and
pricing, in vRealize Business. If you need assistance with such items,
consider hiring Rackspace professional services.
