
vRealize Business compatibility
-------------------------------

The vRealize Business add-on might not be compatible with all Rackspace
products and services. Contact your Rackspace support specialist for detailed
information on compatibility with Rackspace products.


vRealize Business compatibility with third-party products
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

The vRealize Business add-on can be accessed by using public APIs.
For details, see the
`Use Public API for Generating vRealize Business for Cloud Reports
section in the vRealize Business for Cloud 7.1 Information Center <http://bit.ly/2o1gglp>`_.


vRealize Business compatibility when elevated permissions are needed
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

In some cases, existing role permissions provided by Rackspace do not
allow a custom or third-party tool to function. Contact the Rackspace
account team to determine if role permission adjustments are possible.
