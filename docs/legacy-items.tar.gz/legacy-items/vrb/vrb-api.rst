=====================
vRealize Business API
=====================

You can use the vRealize Business public API to integrate your systems with
vRealize Business. For details, see the `Use Public API for Generating
vRealize Business for Cloud Reports section in the vRealize Business for
Cloud 7.1 Information Center <http://bit.ly/2o1gglp>`_.
