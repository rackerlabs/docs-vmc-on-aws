=======================================
VMware vRealize Business for RPC-VMware
=======================================

VMware vRealize® Business™ is a cloud planning, budgeting, and cost
product that can be included as an optional add-on component in
Rackspace Private Cloud powered by VMware (RPC-VMware). It is used to establish
costs and pricing, make cost base decisions, and provide information
for chargeback. It is accessible via a web client and a public API.

This handbook is your primary resource for information related to the
vRealize Business add-on component for RPC-VMware, such as getting
started, using, and getting help. It also includes references to additional
resources external to the handbook.

The vRealize Business add-on component is not available as a
stand-alone product.

.. toctree::
   :maxdepth: 1

   getting-started/index.rst
   vrb-licensing.rst
   vrb-patching-upgrades.rst
   vrb-api.rst
   vrb-using.rst
   vrb-additional-resources.rst
