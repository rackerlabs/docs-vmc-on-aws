===============================
Connecting to vRealize Business
===============================

To connect to vRealize Business, use a web browser to go to vRealize
Automation at **https://<vra-fqdn>**, where
the **<vra-fqdn>** is the fully qualified domain name of the vRealize
Automation appliance. Then, select the **Business Management** tab.
