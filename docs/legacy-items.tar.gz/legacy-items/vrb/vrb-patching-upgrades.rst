========================================
vRealize Business patching and upgrading
========================================

For details about patching and upgrading, see the `main patching and upgrading
section
<https://developer.rackspace.com/docs/rpc-vmware/rpc-vmware-customer-handbook/rpcv-patching-upgrading/>`_
of the handbook.
