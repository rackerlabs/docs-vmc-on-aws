.. _vcloud-director-compatibility:

vCloud Director compatibility
-----------------------------

vCloud Director might not be compatible with all Rackspace products and
services. Contact your Rackspace support specialist for detailed
information about whether any specific Rackspace product is compatible
with your vCloud Director.

Rackspace provides the following add-ons as part of Rackspace Private
Cloud powered by VMware (RPC-VMware):

-  VMware vRealize® Business™

-  VMware vRealize Automation™

-  vRealize Operations™

-  VMware vSAN™

vCloud Director for RPC-VMware is compatible with these add-ons.

vCloud Director compatibility with third-party products
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

You can access vCloud Director by using the vCloud Director API. You can
use any third-party management, orchestration, or other type of tools
that are compatible with the vCloud Director API. In this case, the
functionality of any such tool is limited by the vCloud Director
features and capabilities as described in this handbook. Ensure that the
vCloud Director API version of your environment is compatible with the
third-party tools that you want to use.

vCloud Director compatibility when elevated permissions are needed
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

In some cases, existing role permissions provided by Rackspace do not
allow a custom or third-party tool to function. Contact the Rackspace
account team to determine if role permission adjustments are possible.
