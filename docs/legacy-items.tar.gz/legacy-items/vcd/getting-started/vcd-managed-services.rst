.. _vcloud-director-managed-services:

vCloud Director managed services
--------------------------------

Rackspace offers 24x7x365 support for vCloud Director for RPC-VMware
along with the underlying RPC-VMware service. See the RPC-VMware
handbook for details on the managed services included with RPC-VMware.

The following table describes the vCloud Director features related to
vApps, VMs, and catalogs that Rackspace provides as part of the
managed services.

.. list-table::
   :widths: 30 70
   :header-rows: 1

   * - Feature
     - Description
   * - Publish a customer catalog for external (VCSP) subscription
     - Publish a customer catalog for use between two vCloud Director
       environments via VMware Content Subscription Protocol (VCSP).
   * - Create a customer catalog that is subscribed to an external (VCSP)
       catalog
     - Create a customer catalog that is subscribed to an external catalog.
   * - Enable a catalog item for download
     - Enable templates in a catalog to be downloaded by the customer.
   * - Manage vCloud Director users
     - Manage the vCloud Director users and groups for a customer.
   * - Manage vCloud Director external networks
     - Create, modify, or delete external networks for a customer.
   * - Edit organization email settings
     - Customize the organization email settings as requested by a customer.
   * - Edit organization LDAP settings
     - Customize the organization LDAP settings as requested by a customer.
   * - Edit organization policies settings - leases
     - Customize the organization policies settings - leases as requested by
       a customer.
   * - Edit organization policies settings - quotas
     - Customize the organization policies settings - quotas as requested by
       a customer.
   * - Edit organization policies settings - limits
     - Customize the organization policies settings - limits as requested by
       a customer.
   * - Edit organization guest personalization settings
     - Customize the organization guest personalization settings (Active
       Directory defaults) as requested by a customer.
   * - Edit organization federation settings
     - Customize the organization federation settings (SAML) as requested by
       a customer.
   * - Manually clone VMs
     - Create a copy or template of a VM.
