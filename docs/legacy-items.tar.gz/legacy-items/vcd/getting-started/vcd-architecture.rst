.. _vcloud_director_architecture:

vCloud Director architecture
----------------------------

The following diagram shows the architecture of vCloud Director for
RPC-VMware, including firewalls, load balancers, storage, and VM
locations.

.. figure:: ../../figures/vCloud-director-architecture.png
