.. _vcd-getting-started:

===================================================
Getting started with vCloud Director for RPC-VMware
===================================================

This section provides the following overview information about VMware vCloud
Director for Rackspace Private Cloud powered by VMware (RPC-VMware):

.. toctree::
   :maxdepth: 1

   vcd-architecture
   vcd-components
   vcd-features
   vcd-permissions-roles
   vcd-managed-services
   vcd-support
   vcd-compatibility
   vcd-authentication
