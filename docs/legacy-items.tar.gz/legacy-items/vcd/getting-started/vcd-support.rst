.. _vcloud_director_support:

vCloud Director spheres of support
----------------------------------

With vCloud Director, you can create VMs on demand. The Rackspace
virtualization team maintains the vCloud Director configuration and
services to ensure uptime. The spheres of support remain the same for
RPC-VMware when using vCloud Director for RPC-VMware. See the RPC-VMware
handbook for further details.

Within vCloud Director, the spheres of support are as follows:

-  Rackspace is responsible for all vCloud Director configurations that
   require the System Administrator role.

-  Customers are responsible for all vCloud Director configurations and
   operations that are enabled with the Organizational Administrator role
   unless that configuration or operation has been listed in the managed
   services table in the preceding section.
