.. _vcloud_director_components:

vCloud Director components
--------------------------

vCloud Director for RPC-VMware is provided as an additional VM provisioned in
the Management Resource Pool. The vCloud Director service is installed in a
CentOS VM.

Access to the vCloud Director services is limited to the user interface
or API for vCloud Director. Rackspace manages and maintains servers
running the vCloud Director services. Any changes to settings or
configurations of vCloud Director must be requested by opening a ticket
with Rackspace Support.

NSX for RPC-VMware is a required component of the vCloud Director add-on
and is intended to be accessed through features in the vCloud Director
user interface or API. No direct customer access is provided for NSX
when used with vCloud Director. See the NSX for RPC-VMware add-on
handbook for details about this service.
