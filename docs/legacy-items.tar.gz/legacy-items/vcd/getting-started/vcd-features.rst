.. _vcloud_director_features:

vCloud Director features
------------------------

The following table describes the vCloud Director features related to
vApps, VMs, and catalogs.

.. list-table::
   :widths: 30 70
   :header-rows: 1

   * - Feature
     - Description
   * - Create one or more VMs as a vApp
     - Create vApps with unmanaged VMs from templates provided by Rackspace.
   * - Create one or more unmanaged VMs as a vApp
     - Create vApps with unmanaged VMs from templates provided by Rackspace.
   * - Create one or more customer-provided VMs as a vApp from a template
     - Create vApps with customer-provided VMs using templates by uploading
       OVA/OVF files to a customer catalog.
   * - Create one or more customer-provided VMs as a vApp from an ISO
     - Create vApps with blank VMs that have an OS installed by connecting an
       ISO file from a customer catalog.
   * - Power on, power off, suspend, and resume a VM or entire vApp
     - Stop, start, and suspend a VM or vApp.
   * - Modify a VM
     - Change the resources of a VM, such as the CPU, memory, disk, or name.
   * - Delete a VM
     - Delete a VM.
   * - Access to the vCloud API
     - Access the RESTful vCloud API used to enable automation and integration
       of third-party tools into Dedicated VMware vCloud.
   * - Upload a customer-provided OVA as a vApp
     - Create vApps by uploading an OVA/OVF template to vCloud Director.
   * - Upload a customer-provided OVA as a template to a customer catalog
     - Create vApp templates by uploading an OVA/OVF template to a customer
       catalog.
   * - Upload a customer-provided ISO to a customer catalog
     - Upload ISO files stored in vCloud Director to a customer catalog media
       store.
   * - Access (read-only) the vCenter Server via the vSphere API
     - View vCenter information with read-only permissions from the vSphere
       web or full client, or third-party software. (Customer-provided vSphere
       plug-ins are not supported.)
   * - Access the vCloud Director user interface
     - Use the vCloud Director Web console to operate vCloud Director.
   * - Edit a template or media item in a customer catalog
     - Edit the properties of a created catalog.
   * - Create or delete a customer catalog
     - Create or delete a catalog on the provisioned storage to contain
       uploaded templates or ISO files.
   * - Change the customer catalog owner
     - Reassign the ownership of a catalog to a different vCloud Director
       user account.
   * - Edit customer catalog properties
     - Reassign the ownership of a catalog to a different vCloud Director
       user account.
   * - Publish a customer catalog to another organization in the same
       vCloud Director
     - Choose which vCloud Director organizations can access a created catalog.
   * - Share a customer catalog with other users within the same vCloud
       Director organization
     - Select users in the vCloud Director organization to use the catalog.
   * - Create, modify, and delete VM independent disks
     - Create, modify, and delete independent disks.
   * - Share a vApp with other users in the vCloud organization
     - Share access to a vApp with another user in their vCloud organization.
   * - Snapshot a VM or vApp
     - Create or revert to snapshots of VMs or entire vApps.
   * - Remove a snapshot from a VM or vApp
     - Delete snapshots of VMs or entire vApps.
   * - Access the VM console
     - Use the VM console to interact with a VM.

.. note::
   Raw Device Mapping for virtual machine disks is not supported in the vCloud
   Director platform.
