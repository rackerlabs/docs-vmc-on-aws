.. _vcloud_director_permissions:

vCloud Director roles and permissions
-------------------------------------

Because vCloud Director is a cloud portal that abstracts the resources of
the underlying RPC-VMware environment, your use of the underlying
RPC-VMware services is limited to read-only access to the vCenter Server
user interface and APIs. Although the features listed in the RPC-VMware
handbook are still available, you can only consume those features as
they are enabled in the customer role of the vCloud Director services or
by opening a ticket with Rackspace support to make modifications to the
underlying RPC-VMware services and environment.

Predefined roles
~~~~~~~~~~~~~~~~

To implement the separation of customer and Rackspace duties in
RPC-VMware, Rackspace uses built-in roles in vCloud Director. Rackspace
assigns you a maximum permission role (Organization Administrator) and
any lesser privileged roles that you request for specific users or
groups.

Predefined roles and the rights that they contain are available in all
organizations. All of the roles in the following table are available
for the customer. Rackspace support has the System Administrator role at the
System organization level, which is used to manage the vCloud Director
configurations.

.. note:
   Except for the Defer to Identity Provider role, each predefined role
   includes a set of default rights. Only a system administrator can modify
   the rights in a predefined role. If a system administrator modifies a
   predefined role, the modifications propagate to all instances of the
   role in the system.

.. list-table::
   :widths: 30 70
   :header-rows: 1

   * - Role
     - Description
   * - Organization Administrator
     - After creating an organization, Rackspace assigns the role of
       Organization Administrator to the user or group provided by the
       customer. Users with the Organization Administrator role can use the
       vCloud Director Web console or the vCloud API to manage users and
       groups in their organization and assign them roles, including the
       Organization Administrator role. A user with this role can use the
       vCloud API to create or update role objects that are local to the
       organization. Roles created or modified by an organization
       administrator are not visible to other organizations.
   * - Catalog Author
     - The rights associated with the Catalog Author role allow a user to
       create and publish catalogs.
   * - vApp Author
     - The rights associated with the vApp Author role allow a user to use
       catalogs and create vApps.
   * - vApp User
     - The rights associated with the vApp User role allow a user to use
       existing vApps.
   * - Console Access Only
     - The rights associated with the Console Access Only role allow a user to
       view VM states and properties and to use the guest OS.
   * - Defer to Identity Provider
     - Rights associated with the Defer to Identity Provider role are
       determined based on information received from the user's OAuth or SAML
       Identity Provider. To qualify for inclusion when a user or group is
       assigned the Defer to Identity Provider role, a role or group name
       supplied by the Identity Provider must be an exact, case-sensitive
       match for a role or group name defined in your organization.

       -  If the user is defined by an OAuth Identity Provider, the user is
          assigned the roles named in the roles array of the user's OAuth
          token.

       -  If the user is defined by a SAML Identity Provider, the user is
          assigned the roles named in the SAML attribute whose name appears in
          the ``RoleAttributeName`` element in the organization's 
          ``OrgFederationSettings``.

       If a user is assigned the Defer to Identity Provider role but no
       matching role or group name is available in your organization, the user
       can log in to the organization but has no rights. If an Identity
       Provider associates a user with a system-level role such as System
       Administrator, the user can log in to the organization but has no
       rights. You must manually assign a role to such users.

Permissions
~~~~~~~~~~~~

Customers have the rights to create, delete, and manage VMs within their
vCloud Director. Rackspace manages the vCloud Director Server, vCenter
Server, and ESXi hosts. Customers have limited permissions on hosts and
servers. The following tables detail the vCloud Director permissions for
the predefined roles that can be assigned for customer use.

**Rights associated with catalogs**

.. list-table::
   :widths: 25 25 10 10 10 10 10
   :header-rows: 1

   * - Right
     - Description
     - Admin
     - Catalog Author
     - vApp Author
     - vApp User
     - Console Access Only
   * - Catalog: Add vApp from My Cloud
     - Permission to add a vApp to a catalog from My Cloud.
     - X
     - X
     - X
     -
     -
   * - Catalog: Change Owner
     - Permission to change the owner of a catalog.
     - X
     -
     -
     -
     -
   * - Catalog: Create or delete a Catalog
     - Permission to create and delete catalogs.
     - X
     - X
     -
     -
     -
   * - Catalog: Edit Catalog Properties
     - Permission to edit catalog properties.
     - X
     - X
     -
     -
     -
   * - Catalog: Allow External Publishing or Subscriptions for the Catalogs
     - Permission to publish catalogs for external consumption and to
       subscribe to external catalog feeds.
     - X
     - X
     -
     -
     -
   * - Catalog: Share a Catalog to Users or Groups within Current Organization
     - Permission to share catalogs to users and groups in the same
       organization.
     - X
     - X
     -
     -
     -
   * - Catalog: View Private and Shared Catalogs within Current Organization
     - Permission to view both private and shared catalogs in the organization.
     - X
     - X
     - X
     -
     -
   * - Catalog: View Shared Catalogs from Other Organizations
     - Permission to view catalogs shared from other organizations.
     - X
     -
     -
     -
     -

**Rights associated with independent disks**

.. list-table::
   :widths: 25 25 10 10 10 10 10
   :header-rows: 1

   * - Right
     - Description
     - Admin
     - Catalog Author
     - vApp Author
     - vApp User
     - Console Access Only
   * - Disk: Create
     - Permission to create independent disks.
     - X
     - X
     - X
     -
     -
   * - Disk: Delete
     - Permission to delete independent disks.
     - X
     - X
     - X
     -
     -
   * - Disk: Edit Properties
     - Permission to edit the properties of an independent disk.
     - X
     - X
     - X
     -
     -
   * - Disk: View Properties
     - Permission to view the properties of an independent disk.
     - X
     - X
     - X
     - X
     -

**Rights associated with vApp templates and media**

.. list-table::
   :widths: 25 25 10 10 10 10 10
   :header-rows: 1

   * - Right
     - Description
     - Admin
     - Catalog Author
     - vApp Author
     - vApp User
     - Console Access Only
   * - Catalog Item: Add to My Cloud
     - Permission to add a vApp template or media file to My Cloud.
     - X
     - X
     - X
     - X
     -
   * - Catalog Item: Copy or Move a vApp Template or Media
     - Permission to copy and move vApp templates and media files.
     - X
     - X
     - X
     -
     -
   * - Catalog Item: Create or Upload a vApp Template or Media
     - Permission to create and upload vApp templates and media files.
     - X
     - X
     -
     -
     -
   * - Catalog Item: Enable vApp Template or Media Download
     - Permission to enable a vApp template or media item to be downloaded.
     - X
     - X
     -
     -
     -
   * - Catalog Item: Edit vApp Template or Media Properties
     - Permission to edit the properties of a vApp template or media file.
     - X
     - X
     -
     -
     -
   * - Catalog Item: View vApp Templates or Media
     - Permission to view vApp templates and media files.
     - X
     - X
     - X
     - X
     -

**Rights associated with vApps and Virtual Machines**

.. list-table::
   :widths: 25 25 10 10 10 10 10
   :header-rows: 1

   * - Right
     - Description
     - Admin
     - Catalog Author
     - vApp Author
     - vApp User
     - Console Access Only
   * - vApp: Change Owner
     - Permission to change the owner of a vApp.
     - X
     -
     -
     -
     -
   * - vApp: Copy a vApp
     - Permission to copy a vApp.
     - X
     - X
     - X
     - X
     -
   * - vApp: Create or Reconfigure a vApp
     - Permission to create and reconfigure vApps.
     - X
     - X
     - X
     -
     -
   * - vApp: Delete a vApp
     - Permission to delete a vApp.
     - X
     - X
     - X
     - X
     -
   * - vApp: Download a vApp
     - Permission to download a vApp.
     - X
     - X
     - X
     - X
     -
   * - vApp: Edit vApp Properties
     - Permission to edit a vApp's properties.
     - X
     - X
     - X
     - X
     -
   * - vApp: Edit VM CPU
     - Permission to edit virtual machine CPUs.
     - X
     - X
     - X
     -
     -
   * - vApp: Edit VM Hard Disk
     - Permission to edit virtual machine hard disks.
     - X
     - X
     - X
     -
     -
   * - vApp: Edit VM Memory
     - Permission to edit virtual machine memory.
     - X
     - X
     - X
     -
     -
   * - vApp: Edit VM Network
     - Permission to edit virtual machine network configuration.
     - X
     - X
     - X
     - X
     -
   * - vApp: Edit VM Properties
     - Permission to edit virtual machine properties.
     - X
     - X
     - X
     - X
     -
   * - vApp: Manage VM Password Settings
     - Permission to edit virtual machine password settings.
     - X
     - X
     - X
     - X
     - X
   * - vApp: Start, Stop, Suspend, and Reset a vApp
     - Permission to start, stop, suspend, and reset a vApp
     - X
     - X
     - X
     - X
     -
   * - vApp: Share a vApp
     - Permission to share a vApp.
     - X
     - X
     - X
     - X
     -
   * - vApp: Create, Remove, and Revert a Snapshot
     - Permission to create, revert, and delete virtual machine snapshots.
     - X
     - X
     - X
     - X
     -
   * - vApp: Upload a vApp
     - Permission to upload a vApp.
     - X
     - X
     - X
     - X
     -
   * - vApp: Access to a VM Console
     - Permission to use the virtual machine console.
     - X
     - X
     - X
     - X
     - X
   * - vApp: View VM Metrics
     - Permission to view virtual machine metrics.
     - X
     -
     - X
     - X
     -
   * - vApp: Insert CD
     - Permission to insert a CD into any virtual machine in the vApp.
     - X
     - X
     - X
     - X
     - X
   * - Allow metadata mapping domain to vCenter
     - Permission to apply metadata in the VCENTER domain to a virtual machine.
     - X
     - X
     - X
     -
     -

**Administrative rights**

All of these rights are granted to the system administrator throughout
the system, and to an organization administrator within the
organization. These rights are not granted to any other predefined role.

.. list-table::
   :widths: 35 35 30
   :header-rows: 1

   * - Right
     - Description
     - Admin
   * - General: Administrator Control
     - Permission to use all administrator privileges.
     - X
   * - General: Administrator View
     - Permission to view vCloud Director as an administrator.
     - X
   * - General: Send Notification
     - Permission to send vCloud Director user notifications.
     - X
   * - Gateway: Configure Services
     - Permission to configure gateway services.
     - X
   * - Organization VDC Network: Edit Properties
     - Permission to edit the properties of an organization virtual data
       center network.
     - X
   * - Organization VDC Network: View Properties
     - Permission to view the properties of an organization virtual data
       center network.
     - X
   * - Organization VDC: Set Default Storage Policy
     - Permission to set the default storage policy for an organization
       virtual data center.
     - X
   * - Organization VDC: View Organization VDCs
     - Permission to view organization virtual data centers.
     - X
   * - Organization: Allow Access to All Organization VDCs
     - Permission to access all organization virtual data centers through
       vCloud Air.
     - X
   * - Organization: Edit Federation Settings
     - Permission to edit an organization's federation settings.
     - X
   * - Organization: Edit Leases Policy
     - Permission to edit an organization's leases policy.
     - X
   * - Organization: Edit Organization Network Properties
     - Permission to edit an organization's network properties.
     - X
   * - Organization: Edit Organization Properties
     - Permission to edit organization properties.
     - X
   * - Organization: Edit Password Policy
     - Permission to edit an organization's password policy.
     - X
   * - Organization: Edit Quotas Policy
     - Permission to edit an organization's quotas policy.
     - X
   * - Organization: Edit SMTP Settings
     - Permission to edit an organization's SMTP settings.
     - X
   * - Organization: Edit Organization Associations
     - Permission to edit an organization's associations.
     - X
   * - Organization: Implicitly Import User/Group from IdP While Editing VDC
       ACL
     - Permission to import vCloud Director users and groups while editing
       VDC Access Control Lists in vCloud Air.
     - X
   * - Organization: Edit Access Control List of Organization VDCs
     - Permission to edit the vCloud Air Access Control Lists of organization
       virtual data centers.
     - X
   * - Organization: View Access Control List of Organization VDCs
     - Permission to view the vCloud Air Access Control Lists of organization
       virtual data centers.
     - X
   * - Organization: View Organization Networks
     - Permission to view organization networks.
     - X
   * - Organization: View Organizations
     - Permission to view organizations.
     - X
   * - Organization: Edit Operation Limits
     - Permission to edit an organization's ``OrgOperationLimitsSettings``.
     - X (system administrator only)

**Rights not associated with any predefined role**

The following rights are not associated with any predefined role:

-  vApp: Preserve All ExtraConfig Elements During OVF Import and Export

-  vApp: Preserve Latency ExtraConfig Elements During OVF Import and Export

-  vApp: Preserve Ethernet-Coalescing ExtraConfig Elements During OVF Import
   and Export

-  vApp: Preserve NUMA Node Affinity ExtraConfig Elements During OVF Import
   and Export
