=====================================
VMware vCloud Director for RPC-VMware
=====================================

vCloud Director for Rackspace Private Cloud powered by VMware (RPC-VMware)
provides a cloud portal that is easy to manage. vCloud Director pools
virtual infrastructure resources from RPC-VMware into
virtual data centers and exposes them to users through a web-based
portal and RESTful APIs that enable the creation of a fully
automated, catalog-based service delivery solution.

vCloud Director is a software add-on for RPC-VMware that creates an
abstraction layer on top of VMware vCenter Server. vCloud Director
simplifies tasks like creating virtual machines (VMs). Rackspace
configures the infrastructure, sets up virtual networks, and establishes
storage policies for use in vCloud Director. With the Rackspace catalog
of VMware vApp™ templates in the vCloud Director web console, you can
create VMs for testing, development, or production.

Rackspace can help you set up cloud policies that control how resources
are used. Optionally, you can segregate business units or groups of
users into *organizations* within the hosted private cloud. Users can
provision resources in this application, where they have access to vApps
and the resources used by vApps, without involving IT.

The vCloud Director service can be used to provision VMs only on the
resources provided to you by Rackspace within the same data center. It
is not possible to add your on-premises vSphere resources to vCloud
Director.

This handbook is your primary resource for information related to the
vCloud Director add-on component for RPC-VMware, such as getting
started, using, and getting help. It also includes references to additional
resources external to the handbook.

The vCloud Director add-on component is not available as a
stand-alone product.

.. toctree::
   :maxdepth: 1

   getting-started/index.rst
   vcloud-director-licensing.rst
   vcloud-director-patching-upgrading.rst
   vcloud-director-api.rst
   using/index.rst
   vcloud-director-glossary.rst
   vcloud-director-additional-resources
