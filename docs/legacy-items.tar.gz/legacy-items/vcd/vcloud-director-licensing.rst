.. _vcd-licensing:

=========================
vCloud Director licensing
=========================

For details about licensing, see the `main licensing section
<https://developer.rackspace.com/docs/rpc-vmware/rpc-vmware-customer-handbook/rpcv-licensing/>`_
in the handbook.
