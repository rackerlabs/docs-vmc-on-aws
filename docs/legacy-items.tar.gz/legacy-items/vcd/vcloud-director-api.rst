.. _vcd-api:

===================
vCloud Director API
===================

Detailed API documentation is located in the `VMware API/SDK Documentation <https://www.vmware.com/support/pubs/vcd_sp_pubs.html>`__.

Rackspace does not provide developer support for the vCenter API, vCloud
API, or the APIs for any of the RPC-VMware add-ons. However, Rackspace
can coordinate with VMware to address your questions and issues.
