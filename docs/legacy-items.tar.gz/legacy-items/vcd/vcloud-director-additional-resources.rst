.. _vcd-additional-resources:

========================================
Additional resources for vCloud Director
========================================

To learn more about RPC-VMware and vCloud Director, see the following
resources:

-  `Rackspace Private Cloud powered by VMware product page
   <https://www.rackspace.com/en-us/vmware/vmware-vcloud>`__

-  `Rackspace How-To resources
   <https://support.rackspace.com/how-to/managed-vmware-services/>`__

-  `VMware vCloud Director documentation
   <https://www.vmware.com/support/pubs/vcd_pubs.html>`__
