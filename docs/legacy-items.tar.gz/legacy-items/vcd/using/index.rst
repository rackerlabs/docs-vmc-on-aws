.. _vcloud_director_using:

====================================
Using vCloud Director for RPC-VMware
====================================

This section describes additional details that you need to know to
perform the following vCloud Director tasks:

.. toctree::
   :maxdepth: 2

   vcd-accessing
   vcd-managing
   vcd-working-with-elements

For general details about the use of RPC-VMware, see the
`Rackspace Private Cloud powered by VMware Customer Handbook
<https://developer.rackspace.com/docs/rpc-vmware/rpc-vmware-customer-handbook/>`__.
