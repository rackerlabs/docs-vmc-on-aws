.. _working-with-elements:

Working with vCloud Director elements
-------------------------------------

This section describes how to work with the following vCloud Director
elements:

-  :ref:`Working with catalogs <vcd-catalogs>`

-  :ref:`Working with media files <vcd-media-files>`

-  :ref:`Working with vApps <vcd-vapps>`

-  :ref:`Working with virtual machines <vcd-vms>`

   -  :ref:`Managing virtual machines <vcd-manage-vms>`

   -  :ref:`VM console <vcd-vmconsole>`

   -  :ref:`Snapshots <vcd-snapshots>`

   -  :ref:`Downloading a VM as a template <vcd-vm-template>`

-  :ref:`Working with networks <vcd-networks>`

   -  :ref:`External networks <vcd-external-networks>`

   -  :ref:`Organization networks <vcd-org-networks>`

   -  :ref:`Network pools <vcd-network-pools>`

   -  :ref:`Virtual machines IP management <vcd-vm-ip>`

   -  :ref:`Virtual machine public IP management <vcd-vm-public-ip>`

-  :ref:`Catalog templates <vcd-catalog-templates>`

   -  :ref:`Rackspace catalog templates <rax-catalog-templates>`

.. _vcd-catalogs:

Working with catalogs
~~~~~~~~~~~~~~~~~~~~~

If you purchase an OS license from Rackspace, Rackspace provides
complimentary starter images for deploying VMs when your initial
deployment is complete. Rackspace does not update the images with
patches and updates unless you specifically request it. Rackspace
provides vCloud Director for RPC-VMware customers with templates by
creating a catalog that provides these vApp templates to use when
creating vApps with various operating systems for which you have
purchased OS licenses.

The Rackspace catalog is subscribed to a Content Subscription Endpoint
using the VMware Content Subscription Protocol (VCSP). This catalog is
hosted as a web service in a central location for each Rackspace data
center and synchronized among all Rackspace data centers with
array-based replication. The vCloud Director cells have access to this
catalog using the back-end services network.

For more information about vApp templates, including a full list of the
current vApp templates offered in the Rackspace catalog, see
:ref:`Using catalog templates <vcd-catalog-templates>`.

This section discusses how to add and manage additional catalogs.

Create a customer catalog
^^^^^^^^^^^^^^^^^^^^^^^^^

1. Sign in to the organization where you want to create the catalog.

2. Click the **Catalogs** tab.

3. Click the green + sign to create a new catalog.

4. Enter a name and description for the catalog.

5. If items in the catalog need to be accessed by users other than the
   original creator of the catalog, select the users or groups with whom
   to share the catalog. To share an item with all the users in an
   organization, select the **Everyone in the Organization** option.

.. note:
   If the organization has permission to publish a catalog,
   catalog enables all organizations in the vCloud Director instance to
   access it. The access is read-only; other organizations can deploy items

Sharing across organizations is prohibited. If other organizations
require access to a catalog, it must be published. After a catalog is
published, all organizations can read it. Contact Rackspace Support for
help with publishing a catalog.

Access a catalog
^^^^^^^^^^^^^^^^

#. Click the **Catalogs** tab.

#. In the left pane, click one of the following options:

   -  My Organization's Catalogs

   -  Public Catalogs

#. In the right pane, right-click a catalog and select **Open**.

Share a catalog
^^^^^^^^^^^^^^^

Shared catalogs are available to users in your organization. Users with
the correct rights and access level can use vApp templates and media
from the shared catalog to create their own vApps.

The actions that a user can perform on a catalog and its contents depend
on the user’s rights and access to the catalog. Sharing a catalog with
full control does not grant a user rights that the user does not already
have.

#. Click **Catalogs**.

#. In the left pane, click **My Organization's Catalogs**.

#. Right-click a catalog and select **Share**.

#. Click **Add Members**.

#. Select the users and groups to share with.

   -  Select **Everyone in the organization** to share the catalog with
      everyone.

   -  Select **Specific users and groups**, click specific users and
      groups, and then click **Add**.

#. Select an access level and then click **OK**.

#. Click **OK**.

Delete a catalog
^^^^^^^^^^^^^^^^

When you delete a catalog, it must not contain any vApp templates or
media files. You can move these items to a different catalog or delete
them.

#. Click **Catalogs**.

#. In the left pane, click **My Organization's Catalogs**.

#. Right-click a catalog and select **Delete**.

#. Click **Yes** to confirm the deletion.

   The empty catalog is deleted from your organization.

.. _vcd-media-files:

Working with media files
~~~~~~~~~~~~~~~~~~~~~~~~

To populate a catalog, you add vApp templates or media files. This
section describes how to upload ISO and OVF files to a catalog.

Java Plug-in 1.6.0_10 or later must be installed to complete this
process.

Upload an ISO file
^^^^^^^^^^^^^^^^^^

#. Open a catalog. For instructions, see Access a catalog.

#. Click the **Media & Other** tab, and then click **Upload**.

#. Click **Browse** and navigate to the ISO file.

#. Provide a name and description, and then click **Upload**.

#. To watch the upload progress, click **Uploads and Downloads
   Transfer**.

6. When the file is uploaded, wait until it is imported in vCloud
   Director.

When the status is stopped, the ISO file has been added to the catalog
and can be used to provision new VMs.

Upload an OVF file
^^^^^^^^^^^^^^^^^^

1. Open a catalog. For instructions, see Access a catalog.

2. Click the **vApps Templates** tab, and then click **Upload**.

3. Click **Browse** and navigate to the OVF file.

4. Provide a name and description, and then click **Upload**.

5. To watch the upload progress, click **Uploads and Downloads
   Transfer**.

6. When the file is uploaded, wait until it is imported in vCloud
   Director.

When the status is stopped, the OVF file has been added to the catalog
and can be used to provision new VMs.

Delete media files
^^^^^^^^^^^^^^^^^^

#. Click **Catalogs**, and then click **My Organization's Catalogs**.

#. On the **Media & Other** tab, right-click a media file, and then
   select **Delete**.

#. Click **Yes** to confirm the deletion.

.. _vcd-vapps:

Working with vApps
~~~~~~~~~~~~~~~~~~

vCloud Director uses vApps as containers for all VMs. A vApp can contain
one or more VMs. Before you can create a VM, a vApp must be created
first. By default, all vApps and the VMs that they contain can be seen
and managed only by the user who created them. To enable other vCloud
Director users to interact with a vApp, it must be shared with them.

Building a new empty vApp
^^^^^^^^^^^^^^^^^^^^^^^^^

#. On the **Home** page, click **Build New vApp**.

#. Enter a name and description for the vApp, and then click **Next**.

#. To proceed without creating a VM, click **Next** on the Configure
   Resources page, the Configure Virtual Machines page, and
   the Configure Networking page.

#. Review the settings, and then click **Finish** to create the vApp.

An empty vApp is created. When the process is complete, you can populate
the vApp with VMs.

Building a new vApp and add a VM
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

#. On the **Home** page, click **Build New vApp**.

#. Enter a name and description for the vApp, and then click **Next**.

#. Click **New Virtual Machine**.

#. On the Configure Resources page, enter a name for the VM.

#. On the Configure Virtual Machines page, change the computer name as
   needed.

#. On the Configure Networking page, click **Next**.

#. Review the settings, and then click **Finish**.

A vApp is created with a VM. When the process is complete, you can
populate the vApp with more VMs.

Building a new vApp from an OVF file
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

An OVF file can contain one or more VMs.

1. On the **Home** page, click **Add vApp from OVF**.

2. Browse to the location of the vApp OVF file on a local drive or via a
   URL, and then click **Next**.

3. Review the details and click **Next**.

4. On the Select Name and Location page, name the vApp and choose the
   virtual data center, and then click **Next**.

5. On the Configure Resources page, choose the storage policy, and then
   click **Next**.

6. On the Configure Networking page, name the computer.

7. Choose your customized hardware settings for CPU, memory, and hard
   disk size, and then click **Next**.

8. Review the settings, and then click **Finish** to create the vApp.

A vApp is created from the OVF file. When the process is complete, you
can populate the vApp with VMs.

Restarting a vApp
^^^^^^^^^^^^^^^^^

#. Right-click a vApp and select **Power Off**.

#. Right-click the vApp again and select **Start**.

Suspending and resuming a vApp
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

#. Right-click a vApp and select **Suspend**.

#. Right-click the vApp again and select **Start**.

.. _vcd-vms:

Working with VMs
~~~~~~~~~~~~~~~~~

vCloud Director uses vApps as containers for all VMs. A vApp can contain
one or more VMs. Before you can create a VM, a vApp must be created
first. For more information, see `Working with
vApps <https://developer.rackspace.com/docs/managed-vmware-services/vcloud/v1.5/working-with-vcloud-vapps/#working-with-vapps>`__.

..  note::

    To migrate your existing VMs to Rackspace, they must be packaged in
    OVF or OVA formats and imported into vCloud Director as a VM or
    template. For instructions on exporting to these formats, see the
    documentation of the source system. For additional information about
    migrating workloads to vCloud Director, contact Rackspace Support.

To make changes to an element that appears unavailable, shut down the VM
and make the changes while it is powered off.

VM requirements
^^^^^^^^^^^^^^^

A new VM must meet the following requirements.

**Networking**

    You are responsible for tracking the IP allocation in your
    environment and correlating the CSV file that has been provided to
    you to determine the public IP address for any private IP address
    allocated.

    Because the firewall is configured to deny access by default, you
    must add ACL rules to allow inbound access to the new VM.

    Rackspace does not support the use of advanced networking features
    such as routed, isolated, or fenced vApp networks in vCloud
    Director. All VM network connections must be made directly to the
    Rackspace-provided external networks.

**Passwords**

    All vCloud Director VMs can use the administrator or root password
    set by using guest customization as displayed in the VM properties.

**Storage**

    Although storage policies are used to abstract the placement of VM
    disks onto specific datastores, there are certain limitations that
    apply to vApps and VM disk files. An entire vApp, including all VMs
    and their virtual disk files, must be contained within the same
    datastore for a selected storage policy. Thus the largest available
    free space of any given datastore within a storage policy becomes
    the current limit to the size of vApp that can be provisioned.

.. _vcd-manage-vms:

Adding a VM to a vApp
^^^^^^^^^^^^^^^^^^^^^

#. Double-click the vApp.

#. Click the green (+) button to add a single VM to the vApp.

#. Select one of more VMs to add from the catalog and click **Add**, or
   create a completely new VM by clicking **New Virtual Machine**.

#. If you are creating a new VM, select the machine name and hardware
   settings.

#. Select the storage profile where the new VMs are to be placed.

#. Select the network connectivity.

#. Customize the hardware of each VM before adding it to the vApp.

#. Click **Finish**.

The VMs are added to the vApp.

Restarting a VM
^^^^^^^^^^^^^^^

1. Right-click a VM and select **Shut Down Guest OS**.

2. Right-click the VM again and select **Power On**.

Suspending and resume a VM
^^^^^^^^^^^^^^^^^^^^^^^^^^

#. Right-click a VM and select **Suspend**.

#. Right-click the VM again and select **Resume**.

Modifying a VM
^^^^^^^^^^^^^^

#. Right-click the VM that you want to modify and
   select **Properties**.

#. Edit the lease, CPU, and memory, as needed.

Deleting a VM
^^^^^^^^^^^^^

#. Shut down the VM.

#. Right-click the VM and select **Delete**.

#. Delete any ACLs created on personal firewalls in the MyRackspace
   portal.

When a VM is deleted, it is not retrievable. Rackspace does not maintain
backups of VMs. We recommend that you create your own backups in case of
accidental deletion.

Organization policies can be used to preserve VMs for a short period of
time after deletion by setting a vApp Storage Cleanup option. This
feature is disabled by default because a deleted VM will continue to
occupy storage resources until the cleanup delay time expires and the VM
is actually deleted from storage. To request customization of any
settings in your vCloud Director environment, contact Rackspace Support.

.. _vcd-vmconsole:

Using the VM console
^^^^^^^^^^^^^^^^^^^^

To access the VM console, right-click a VM and select **Popout
Console**. You can also access the VM by double-clicking its icon.

When you first connect to the console, the browser might prompt the
download of a client plug-in for the console. You might need to manually
accept the certificate of the console before you can access a console
session. To manually accept the certificate point, open the custom
console URL in your browser.

.. _vcd-snapshots:

Using snapshots
~~~~~~~~~~~~~~~

A snapshot captures the state of a VM.

-  To create a snapshot, right-click a VM and select **Create
   Snapshot**.

-  To revert to a previous snapshot, right-click a VM and select
   **Revert to Snapshot**.

-  To delete an unneeded snapshot, right-click a VM and select **Remove
   Snapshot**.

When you revert to a previous snapshot, we recommend that you remove the
snapshot as soon as the new VM's settings have been confirmed and the VM
is working as expected. As time elapses between the snapshot and any
updates, performance decreases. As the delta file continues to grow, the
VM can become unstable or experience data loss. Running out of disk
space can cause not only the snapshot VM to become unresponsive, but
also any other VMs running on the same datastore.

.. _vcd-vm-template:

Downloading a VM as a template
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

To download a VM as a template from vCloud Director, submit a request to
Rackspace to enable a template or media file in the catalog for
download. When the request is met, you can download the item from the
catalog. You can also save an existing Rackspace-provided or
customer-provided VM as a template in the catalog and request that
Rackspace enable the template for download.

The ability to download an existing powered-off vApp is currently
disabled.

.. _vcd-networks:

Working with networks
~~~~~~~~~~~~~~~~~~~~~

External networks and network pools are the building blocks of the
vCloud Director network infrastructure.

vCloud Director supports the use of only the following networks and
network pools:

-  External networks

-  Direct organization networks

-  Port-group-backed network pools with static IP pool assignments

.. _vcd-external-networks:

External networks
^^^^^^^^^^^^^^^^^

External networks are the foundation of organization networks. If the
organization network must access a corporate network or the Internet, it
moves along an external network.

Configuring an external network requires preconfiguration in vCenter and
for all hosts to have access to the new port group. After this
configuration is completed, the external network can be added to vCloud
Director.

.. figure:: ../../figures/external-network.png

Setting up an external network requires the following layer 3
information:

-  Gateway

-  Subnet mask

-  DNS address

-  IP address

This information is abstracted from the end user and is used to directly
connect VMs to the external network. The pool of IP addresses is
reserved for use only with vCloud Director. If these addresses are not
reserved and are used outside of vCloud Director, network conflicts
occur.

.. _vcd-org-networks:

Organization networks
^^^^^^^^^^^^^^^^^^^^^

An organization is a logical representation of a tenant in vCloud
Director. End users and resources are allocated and defined here. In
each organization, only direct networks can be configured. Direct
networks connect an organization to an external network by directly
connecting to a port group where the external network is. A VM uses one
IP address from a list of IP addresses that is configured when the
network is created.

.. figure:: ../../figures/organization-network.png

.. _vcd-network-pools:

Network pools
^^^^^^^^^^^^^

A network pool is a group of network resources that can be used only by
an organization. These network resources can be either logical or
physical. The network pool shares the IP address pool with the
organization and vApp networks for NAT routing.

vCloud Director supports port-group-backed network pools, which can be
used by vApps. Port-group-backed pools require pre-created port groups
within the vSphere environment. Rackspace uses a port-group-backed layer
2 network, which enables autonomous control of the network resources and
ease of configuration.

.. _vcd-vm-ip:

VM private IP management
^^^^^^^^^^^^^^^^^^^^^^^^

vCloud Director can be configured to allocate local private IP addresses
to VMs automatically, allow you to manually specify an IP address or use
a DHCP server for IP address allocation. When assigning an IP address to
a VM, you have the following options:

-  Static IP pool

-  DHCP

-  Static manual

The following image shows the options for the IP mode and the options
for choosing the network:

.. figure:: ../../figures/select-a-network.png

**Static IP pool**

The static IP pool is a pool of IP addresses that is defined when a
newly created network is connected. A private IP pool is created when a
routed network, internal network, or a vApp network is created. When you
connect the vNIC to a network with the static IP pool selected, it
automatically pulls an IP address from the pool at guest customization
time and considers it a static IP address.

**DHCP**

This is standard DHCP services, usually provided by a vShield Edge if it
is a vApp network or a routed network. When the vNIC starts, it requests
a DHCP lease from the network. When it reaches half its lease, it
requests an extension. When it is not used and the lease expires, the
address is returned to the pool.

**Static manual**

This option manually assigns an IP address to the vNIC, providing it an
IP address and subnet mask. The IP address is persistent until it is
changed.

.. _vcd-vm-public-ip:

Assigning public IP addresses
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

For details on assigning public IP addresses to VMs that you create,
see the
`Rackspace Private Cloud powered by VMware Customer Handbook
<https://developer.rackspace.com/docs/rpc-vmware/rpc-vmware-customer-handbook/rpcv-using/#assigning-public-ip-addresses>`__.

.. _vcd-catalog-templates:

Using catalog templates
~~~~~~~~~~~~~~~~~~~~~~~

Rackspace provides a catalog of complimentary OS templates if you have
purchased OS licenses. The following table lists the templates that have
been developed for inclusion in the Rackspace catalog. This list will be
updated as new templates are developed.

.. _rax-catalog-templates:

**Rackspace catalog templates**

.. list-table::
   :widths: 30 70
   :header-rows: 1

   * - Template type
     - Templates available
   * - Windows OS
     - Windows 2012, Windows 2008 R2 Standard
   * - Linux OS
     - Red Hat Enterprise Linux 6, Red Hat Enterprise Linux 7.1
