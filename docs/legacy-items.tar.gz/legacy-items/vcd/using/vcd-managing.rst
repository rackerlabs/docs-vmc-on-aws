.. _managing-vcloud-director:

Managing vCloud Director
------------------------

This section describes the vCloud Director interface and the following
tasks:

-  :ref:`Using the vCloud Director web console <vcloud-director-web-console>`

-  :ref:`Setting vCloud Director user preferences <vcloud-director-setup>`

-  :ref:`Managing virtual data centers <vcloud-director-manage-vdc>`

-  :ref:`Monitoring virtual data centers <vcloud-director-monitor-vdc>`

-  :ref:`Managing vApp leases <vcloud-director-manage-vapp-lease>`

.. _vcloud-director-web-console:

Using the vCloud Director Web console
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

The vCloud Director Web console contains the following tabs:

-  The **Home** tab displays the running vApps in the environment and
   the number of days until their lease expires. On the right side of
   the tab, a Tasks section gives quick access to most tasks and to
   organization management links.

-  The **My Cloud** tab displays the vApps and VMs. The tab also
   displays expired items and logs. This tab enables creation of vApps
   from catalog or OVF.

-  The **Catalogs** tab displays the catalogs, vApp templates, and
   media. The resources to create new vApps and the Rackspace-provided
   catalogs of VM templates are also displayed. The Rackspace catalog is
   read-only, but any additional catalogs are available through the
   following subtabs:

   -  Use the **Media & Other** tab to upload or access ISOs.

   -  Use the **vApp Templates** tab to load new templates. Modified
      or existing templates can be copied and removed from the
      inventory.

   -  Use the **Catalogs** tab to access catalogs and change some
      properties.

.. _vcloud-director-setup:

Setting vCloud Director user preferences
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

To set user preferences, click the **Preferences** link at the top
right of the page to open the **Edit User Preferences** menu.

You can set the following preferences:

-  Default login page

-  The length of time to send out lease alerts before the time of
   expiration

If your account is an internal vCloud Director account, you can also
change a password by selecting **Change Password**.

.. _vcloud-director-manage-vdc:

Managing virtual data centers
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

To manage a virtual data center (VDC), navigate to the **Home** tab
and click **Manage VDCs** on the top right of the page. Most of the
settings here are dimmed and cannot be changed. If you need to change
any of these settings, contact Support.

.. _vcloud-director-monitor-vdc:

Monitoring virtual data centers
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Monitoring the available resources is important. The following procedure
shows where to audit vApps, templates, media, storage policies, and
available organization VDC networks.

#. On the **Home** tab, click **Org Settings** on the top right of
   the page.

#. Under **Cloud Resources**, click **Virtual Datacenters**.
   All virtual data centers (VDCs) and their allocation models are
   displayed.

#. Click the **Monitor** tab to see the current resources used by the
   vApps and templates that you have provisioned. You can review the
   following information:

   -  vApps and their running status

   -  Templates, media, and storage policies

   -  Organization VDC networks and their current IP pool consumption

.. _vcloud-director-manage-vapp-lease:

Managing vApp leases
~~~~~~~~~~~~~~~~~~~~

To reset the lease on a vApp, you do not have to wait for it to expire.
You can reset a vApp lease before it expires if the vApp is required for
longer than expected. Expired leases can be renewed or deleted.

Reset a lease
^^^^^^^^^^^^^

#. Click the **My Cloud** tab.

#. In the left pane, click **vApps**.

#. Right-click the vApp for which you want to reset the lease, and
   select **Properties**.

#. On the **General** tab, select the **Reset leases** check box,
   select a runtime and storage lease, and click **OK**.

Reset an expired lease
^^^^^^^^^^^^^^^^^^^^^^

#. Click the **My Cloud** tab.

#. In the left pane, click **Expired Items**, **Expired vApps**,
   or **Expired vApp Templates**, depending on the type of lease to
   reset.

#. Right-click the expired vApp for which you want to reset the lease,
   and select **Renew**.

   The restored vApp appears on the vApps page.

Delete an expired lease
^^^^^^^^^^^^^^^^^^^^^^^

#. Click the **My Cloud** tab.

#. In the left pane, click **Expired Items**, **Expired vApps**,
   or **Expired vApp Templates**, depending on the type of lease to
   delete.

#. Right-click the expired vApp for which you want to delete the
   lease, and select **Delete**.

   The vApp is deleted from the list.
