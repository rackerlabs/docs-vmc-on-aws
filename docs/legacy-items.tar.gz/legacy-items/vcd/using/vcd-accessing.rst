.. _access-environment:

Accessing the vCloud Director environment
-----------------------------------------

The vCloud Director environment is accessible via a web browser and API
calls. Rackspace provides the URL for the vCloud Director Web console
and vCloud API. The following information is specific to the vCloud
Director Web console. For information about the using the vCloud API,
see the VMware Documentation portal.

vCloud Director is accessible only over a VPN connection to Rackspace.
This connection can be configured for site-to-site VPN or single-user
VPN connections. Rackspace provides the VPN details.

To access the vCloud Director environment, follow these steps:

#. Navigate to the URL in the browser.

#. In the login page, enter the login and password details, and then
   press **Enter**.
