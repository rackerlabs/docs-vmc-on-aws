========================================
Using vRealize Automation for RPC-VMware
========================================

This section provides instructions for using the vRealize Automation
add-on for RPC-VMware.

Connecting to vRealize Automation
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

To connect to vRealize Automation, use a web browser to go to
**https://<vra-fqdn>**, where **<vra-fqdn>** is the fully qualified
domain name of the vRealize Automation appliance.

Verifying that vRealize Automation is running
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Navigate to **Administration** > **Tenant** and verify that the tenant
information successfully appears.

Navigate to **Infrastructure** > **Endpoints** > **Endpoints** and
verify that the local vCenter Server endpoint successfully appears.

Adding endpoints to vRealize Automation
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

For convenience, Rackspace configures the vSphere endpoint to connect
vRealize Automation to the vCenter Server in your RPC-VMware cloud.
The endpoint includes NSX as the network and security platform. You
can add endpoints, but you must contact your Rackspace Support Team
to install the required agents in the vRealize Automation IaaS Server.


Managing permissions
~~~~~~~~~~~~~~~~~~~~

You are granted the role of Tenant Administrator. You have the ability
and are responsible for delegating vRealize Automation roles as needed.
