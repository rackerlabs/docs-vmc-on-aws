=========================================
VMware vRealize Automation for RPC-VMware
=========================================

VMware vRealize® Automation™ is a cloud automation product that can
be included as an optional component in Rackspace Private Cloud
powered by VMware (RPC-VMware). It can be used to provide cloud-based services
on demand via self-service consumer catalogs. These services can include
typical data-center operations, such as deploying virtual machines
(VMs), applications, and infrastructure, as well as anything for which
you can build a workflow in vRealize Orchestrator.

Without vRealize Automation, the private cloud might offer a Software-Defined
Data Center (SDDC), but it would lack cloud automation. With vRealize
Automation, you can enable consumers, who have no vSphere knowledge, to
deploy and manage applications and associated VMs and infrastructure via
easy-to-use wizards. You can treat these consumers as a single tenant or as
multiple tenants corresponding to your organization’s business units or
customers.

This handbook is your primary resource for information related to the
vRealize Automation add-on component for RPC-VMware, such as getting
started, using, and getting help. It also includes references to additional
resources external to the handbook.

The vRealize Automation add-on component is not available as a
stand-alone product.

.. toctree::
   :maxdepth: 1

   getting-started/index.rst
   vra-licensing.rst
   vra-patching-upgrading.rst
   vra-api.rst
   vra-vpc-usage.rst
   vra-additional-resources.rst
