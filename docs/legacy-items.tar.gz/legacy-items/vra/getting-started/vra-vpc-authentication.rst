==========================================
vRealize Automation authentication methods
==========================================

The vRealize Automation add-on for RPC-VMware might be configured to use
Rackspace hosted Active Directory (intensive.int) or a customer maintained
Active Directory, in a similar manner as RPC-VMware.
For details, see the `Authentication methods in the Rackspace
Private Cloud powered by VMware Customer Handbook
<https://developer.rackspace.com/docs/rpc-vmware/rpc-vmware-customer-handbook/rpcv-getting-started/#rpc-vmware-authentication-methods>`_.

vRealize Automation provides single sign-on support and identity management
by means of an embedded VMware Identity Manager that is administered by the
`Directories Management
<http://pubs.vmware.com/vra-70/index.jsp#com.vmware.vrealize.automation.doc/GUID-72FB0B20-FABC-4F80-9D83-C357861F3751.html>`_
feature. Customer users, who are granted the Tenant Administrator
role, may create and manage Active Directory links to support vRealize
Automation tenant user authentication and authorization. Additionally,
the customer may configure additional `Identity Providers
<http://pubs.vmware.com/vra-70/index.jsp#com.vmware.vrealize.automation.doc/GUID-72FB0B20-FABC-4F80-9D83-C357861F3751.html>`_
and `Network Ranges
<http://pubs.vmware.com/vra-70/index.jsp#com.vmware.vrealize.automation.doc/GUID-93F7569C-D228-4386-8B8D-324E110AFAF6.html#GUID-93F7569C-D228-4386-8B8D-324E110AFAF6>`_.
