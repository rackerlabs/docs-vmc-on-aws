=======================================================
Getting started with vRealize Automation for RPC-VMware
=======================================================

This section provides the following information about the VMware vRealize
Automation add-on component for Rackspace Private Cloud powered by VMware
(RPC-VMware):


.. toctree::
   :maxdepth: 1

   vra-vpc-architecture.rst
   vra-vpc-components.rst
   vra-vpc-features.rst
   vra-vpc-roles.rst
   vra-vpc-services.rst
   vra-vpc-spheres-support.rst
   vra-vpc-compatibility.rst
   vra-vpc-authentication.rst
