======================================
vRealize Automation spheres of support
======================================

Rackspace completely manages and supports the vRealize Automation appliance
and vRealize Automation IaaS server. Rackspace is responsible for keeping
the appliance and IaaS server up and running and for backing up and restoring
them as needed.

Rackspace is the solution provider. Rackspace's responsibilities are as
follows:

-  Install the solution.

-  Perform initial configuration.

-  Connect the required endpoint to the local vCenter Server.

-  Share the System Administrator role with the customer.

-  Back up the solution configuration and data.

-  Configure and respond to monitoring of vRealize Automation services.

-  When required, restore the solution, configuration, and data.

-  When required, install additional vRealize Automation agents to allow
   the customer to connect to additional endpoints.

Customers are expected to self-manage the blue prints, services, catalogs, and
other items that they create in vRealize Automation. Customers are expected to
self-manage the VMs and guest OS that they deploy. The customer monitors the
progress of services executed by vRealize Automation users and remediates
issues.
