=========================================
vRealize Automation roles and permissions
=========================================

To implement the separation of customer and Rackspace duties
in vRealize Automation, Rackspace implements vRealize Automation roles.

Rackspace retains the system administrator role, whilst the customer is
the private cloud administrator and primary tenant.
The customer can delegate responsibilities as required, including
assigning tenant administrator roles to users as they see fit.

As holder of the System Administrator role, Rackspace is required to create
additional tenants, assign additional IaaS administrators if requested by the
customer, and also monitor system level logs.

All other roles are assigned to the customer, as detailed below:

-  IaaS Administrator

-  Tenant Administrator

-  Fabric Administrator

-  Application Architect

-  Infrastructure Architect

-  Software Architect

-  XaaS Architect

-  Catalog Administrator

-  Approval Administrator

-  Approver

-  Business Group Manager

-  Support User

-  Business User

The following table lists the permissions that are associated with each role.

.. list-table::
   :widths: 30 35 35
   :header-rows: 1

   * - Role
     - Description
     - Permissions
   * - System Administrator
     - * Installs
         vRealize Automation and is responsible for ensuring its
         availability for other users. The System Administrator creates
         tenants and manages system-wide configuration such as system
         defaults for branding and notification providers. This role is
         also responsible for monitoring system logs. In a single-tenant
         deployment, the same person might also act as the Tenant
         Administrator.
       * Built-in administrator credentials are specified when single sign-on
         is configured.
     - * Create tenants.
       * Configure tenant identity stores.
       * Assign the IaaS Administrator role.
       * Assign the Tenant Administrator role.
       * Configure system default branding.
       * Configure system default notification providers.
       * Monitor system event logs, not including IaaS logs.
       * Configure the vRealize Orchestrator server for use with XaaS.
       * Create and manage (view, edit, and delete) reservations
         across tenants if also a Fabric Administrator.
   * - IaaS Administrator
     - * Manages cloud, virtual, networking, and
         storage infrastructure at the system level, creating and
         managing endpoints and credentials, and monitoring IaaS logs.
         IaaS administrators organize infrastructure into tenant-level
         fabric groups, appointing the fabric administrators who are
         responsible for allocating resources within each tenant through
         reservations and reservation, storage, and networking policies.
       * The System Administrator designates the IaaS Adminstrator when
         configuring a tenant.
     - * Configure IaaS features and global properties.
       * Create and manage fabric groups.
       * Create and manage endpoints.
       * Manage endpoint credentials.
       * Configure proxy agents.
       * Manage Amazon AWS instance types.
       * Monitor IaaS-specific logs.
       * Create and manage (view, edit, and delete) reservations
         across tenants if also a fabric administrator.
   * - Tenant Administrator
     - * Typically a line-of-business administrator, business manager,
         or IT administrator who is responsible for a tenant. Tenant
         Administrators configure vRealize Automation for the needs of
         their organizations. They are responsible for user and group
         management, tenant branding and notifications, and business
         policies such as approvals and entitlements. They also track
         resource usage by all users within the tenant and initiate
         reclamation requests for virtual machines.
       * The System Administrator designates a Tenant Administrator when
         creating a tenant. Tenant Administrators can assign the role to
         other users in their tenant at any time from the Administration
         tab.
     - * Customize tenant branding.
       * Manage tenant identity stores.
       * Manage user and group roles.
       * Create custom groups.
       * Manage notification providers.
       * Enable notification scenarios for tenant users.
       * Configure vRealize Orchestrator servers, plug-ins and
         workflows for XaaS.
       * Create and manage catalog services.
       * Manage catalog items.
       * Manage actions.
       * Create and manage entitlements.
       * Create and manage approval policies.
       * Monitor tenant machines and send reclamation requests.
   * - Fabric Administrator
     - * Manages physical machines and compute resources assigned to
         their fabric groups and creates and manages the reservations
         and policies associated with those resources within the scope
         of their tenant. Fabric Administrators also manage property
         groups, machine prefixes, and the property dictionary that are
         used across all tenants and business groups.

         **Note**: If you add the Fabric Administrator role to a system-wide
         role such as IaaS Administrator or System Administrator, the
         Fabric Administrator can create reservations for any tenant,
         not just their own.

       * The IaaS Administrator designates the Fabric Administrator when
         creating or editing fabric groups.
     - * Manage property groups.
       * Manage compute resources.
       * Manage network profiles.
       * Manage Amazon EBS volumes and key pairs.
       * Manage machine prefixes.
       * Manage property dictionary.
       * Create and manage reservations and reservation policies in
         their own tenant.
       * If this role is added to a user with IaaS Administrator or
         System Administrator privileges, the user can create and
         manage reservations and reservation policies in any tenant.
   * - Blueprint Architects
     - * Umbrella term for the individuals who are responsible for
         creating blueprint components and assembling the blueprints
         that define catalog items for consumers to request from the
         service catalog. These roles are typically assigned to
         individuals in the IT department, such as architects or
         analysts.
       * Blueprint Architects include Application, Infrastructure, Software,
         and XaaS Architects.
       * Tenant Administrators can assign this role to users in their
         tenant at any time from the Administration tab.
     - See the following rows for Application, Infrastructure, Software,
       and XaaS Architects.
   * - Application Architect
     - Tenant Administrators can assign this role to users in their
       tenant at any time from the Administration tab.
     - Assemble and manage composite blueprints.
   * - Infrastructure Architect
     - Tenant Administrators can assign this role to users in their
       tenant at any time from the Administration tab.
     - * Create and manage infrastructure blueprint components.
       * Assemble and manage composite blueprints.
   * - Software Architect
     - Tenant Administrators can assign this role to users in their
       tenant at any time from the Administration tab.
     - * Create and manage software blueprint components.
       * Assemble and manage composite blueprints.
   * - XaaS architect
     - Tenant Administrators can assign this role to users in their
       tenant at any time from the Administration tab.
     - * Define custom resource types.
       * Create and publish XaaS blueprints.
       * Create and manage resource mappings.
       * Create and publish resource actions.
   * - Catalog Administrator
     - * Creates and manages catalog services and manages the placement
         of catalog items into services.
       * Tenant Administrators can assign this role to users in their
         tenant at any time from the Administration tab.
     - * Create and manage catalog services.
       * Manage catalog items.
       * Assign icons to actions.
   * - Approval Administrator
     - * Defines approval policies. These policies can be applied to
         catalog requests through entitlements that a Tenant
         Administrator or business group manager manage.
       * Tenant Administrators can assign this role to users in their
         tenant at any time from the Administration tab.
     - Create and manage approval policies.
   * - Approver
     - * Any user of vRealize Automation, for example, a line manager,
         finance manager, or project manager, can be designated as an
         Approver as part of an approval policy.
       * The Tenant Administrator or Approval Administrator creates
         approval policies and designates the Approvers for each policy.
     - Approve service catalog requests, including provisioning
       requests or any resource actions.
   * - Business Group Manager
     - * Manages one or more business groups. Typically a line manager
         or project manager. Business Group Managers manage entitlements for
         their groups in the service catalog. They can request and
         manage items on behalf of users in their groups.
       * The Tenant Administrator designates the business group manager
         when creating or editing business groups.
     - * Add and delete users within their business group.
       * Assign support user roles to users in their business group.
       * Assign support user roles to users in their business group.
       * Request and manage items on behalf of a user in their
         business group.
       * Monitor resource usage in a business group.
       * Change the machine owner.
   * - Support User
     - * A role in a business group. Support Users can request and
         manage catalog items on behalf of other members of their
         groups. This role is typically an executive administrator or
         department administrator.
       * The Tenant Administrator designates the Support User when
         creating or editing business groups.
     - * Request and manage items on behalf of other users in their
         business group.
       * Change the machine owner.
   * - Business User
     - * Any user in the system can be a consumer of IT services. Users
         can request catalog items from the service catalog and manage
         their provisioned resources.
       * The Tenant Administrator designates the Business Users who can
         consume IT services when creating or editing business groups.
     - * Request catalog items from the service catalog.
       * Manage their provisioned resources.
