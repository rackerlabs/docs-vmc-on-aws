vRealize Automation components
==============================

The vRealize Automation for RPC-VMware component includes a vRealize
Automation appliance, a vRealize Automation IaaS server, and a vRealize
Automation endpoint connected to the vCenter Server. The network and
security platform of the endpoint is set to the URL of VMware NSX® Manager™.

.. list-table::
   :widths: 30 70
   :header-rows: 1

   * - Component
     - Description
   * - vRealize Automation appliance
     - The vRealize Automation appliance is the management component of
       vRealize Automation. It is a virtual appliance that is deployed in the
       management resource pool. It provides orchestration and the user
       interface.
   * - vRealize Automation IaaS server
     - The vRealize Automation IaaS server is the workhorse component of
       vRealize Automation. It is a Windows-based application that manages
       endpoints and provides model management. It executes the catalog-based
       services that are delivered on demand by vRealize Automation.
   * - vSphere endpoint
     - The vSphere endpoint is used to allow the vRealize Automation IaaS
       server to connect to vCenter Server to provide vSphere automation.
       NSX is configured as the endpoint’s network and security platform, so
       that vRealize Automation can provide NSX network automation.
