.. _vras-managed-services:

====================================
vRealize Automation managed services
====================================

Rackspace provides support to keep the vRealize Automation add-on available
and functioning correctly. Rackspace ensures that the vRealize Automation
appliance and the vRealize Automation IaaS server are running, as well as
each service provided by the appliance and vRA IaaS server.

Rackspace is not responsible for creating catalogs, services, blueprints,
and other items in vRealize Automation. If you need assistance with such
items, contact your account team for information about our professional
services.
