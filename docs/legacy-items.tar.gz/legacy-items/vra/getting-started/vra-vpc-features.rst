============================
vRealize Automation features
============================

This section lists the features of vRealize Automation that are available
for your use within the RPC-VMware environment and your customer permissions.
Features not listed here either need to be performed by Rackspace (see the
:ref:`vRealize Automation managed services section<vras-managed-services>`)
or might be unavailable within the RPC-VMware product and its add-on services.

The following table describes the features of vRealize Automation.

.. list-table::
   :widths: 30 70
   :header-rows: 1

   * - Feature
     - Description
   * - Self-service experience
     -
       - Provide investment protection for current and future technology
         choices.

       - Deliver governance and control to enable hybrid cloud deployments.

       - Flexibility to choose the right cloud platform and location that
         meets the business needs.
   * - Deploy across multivendor, hybrid cloud infrastructure
     -
       - Provide investment protection for current and future technology
         choices.

       - Deliver governance and control to enable hybrid cloud deployments.

       - Flexibility to choose the right cloud platform and location that
         meets the business needs.
   * - Unified blueprint model via design canvas, command line, or API
     -
       - Streamline the design process by assembling applications from
         pre-built components by using a visual canvas with a drag and drop
         interface.

       - Export, import, and edit automation blueprints as text.

       - Enable the entire design and management process via API
         calls based on role-based authorizations.

       - Leverage a library of VMware and partner-provided blueprints.
   * - Extensible automation platform
     -
      - Comprehensive purpose-built functionality and broad
        multivendor, multicloud support is built-in.

      - Adapt and extend vRealize Automation comprehensive,
        purpose-built functionality.

      - Automate the delivery of any IT services.

      - Leverage VMware and partner-provided solutions in the VMware Cloud
        Management Marketplace.
   * - Build on-demand, catalog-based services
     - Configure and entitle catalog services as needed.
   * - Configure custom services (XaaS)
     - Configure services for any workflows that you create in
       vRealize Orchestrator.
   * - Configure application services (SaaS)
     - Configure on-demand services to deploy and manage
       applications.
   * - Configure IaaS
     - Configure on-demand services to provision VMs and infrastructure.
       With NSX for RPC-VMware, you can provide virtual network services
       on-demand.
   * - Integrate with multivendor software tools
     - Configure vRealize Automation services that integrate with third-party
       software configuration management tools, such as Ansible, Puppet,
       and Microsoft SCCM.
   * - Apply business policies, such as approvals
     - Implement approvals, reservations, entitlements, and
       other vRealize Automation features to apply your business policies.
   * - Import existing VMs
     - Import existing VMs from the vCenter Server endpoint to
       be managed by vRealize Automation.
   * - Integrate with vRealize Orchestrator
     - Use the vRealize Orchestrator instance that is
       embedded in the vRealize Automation appliance to integrate with
       the external system
       and to create custom workflows that you provide as a service.
       This is called anything as a service (XaaS).
   * - Use vRealize Automation SDK
     - Use the vRealize Automation SDK to provide software application
       interfaces.
   * - Add tenants
     - Use your private cloud as a single tenant or configure
       multiple tenants corresponds to groups of users per your use
       case.
