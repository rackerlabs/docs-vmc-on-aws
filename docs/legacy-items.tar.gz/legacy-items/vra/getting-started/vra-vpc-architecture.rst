================================
vRealize Automation architecture
================================

The following diagram illustrates the vRealize Automation add-on architecture.
The vRealize Automation components are explained in the next section.


.. figure:: ../../figures/vra-vpc-architecture-1.png
   :alt: vRA for RPC-VMware Architecture
