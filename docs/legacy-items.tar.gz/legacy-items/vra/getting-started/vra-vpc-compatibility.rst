=================================
vRealize Automation compatibility
=================================

The vRealize Automation add-on for RPC-VMware might not be compatible
with all Rackspace products and services. Contact your Rackspace support
specialist for detailed information about whether any specific Rackspace
product is compatible with your vRealize Automation for RPC-VMware.

vRealize Automation compatibility with third-party products
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

The vRealize Automation add-on can be accessed by using the vRealize
Automation API. You can use any third-party management, orchestration,
or other type of tools that are compatible with the vRealize Automation
API. In this case, the functionality of any such tool will be limited
by the vRealize Automation for RPC-VMware features and capabilities
as described in this handbook. Ensure that the vRealize Automation API
version of your environment is compatible with the third-party tools
that you want to use.


vRealize Automation compatibility when elevated permissions are needed
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

In some cases, existing role permissions provided by Rackspace do not
allow a custom or third-party tool to function. Contact the Rackspace
account team to determine if role permission adjustments are possible.
