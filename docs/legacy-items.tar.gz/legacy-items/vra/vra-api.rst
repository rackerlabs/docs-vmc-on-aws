=======================
vRealize Automation API
=======================

You can use the vRealize Automation API to integrate your systems with
vRealize Automation. For more information, see `vRealize Automation SDK 7.0
<https://developercenter.vmware.com/web/sdk/7.0.0/vrealize-automation>`_.
