============================================
Additional resources for vRealize Automation
============================================

The following resources are recommended for vRealize Automation:

- `VMware Hands on Lab: HOL-1721-USE-2 - vRealize Automation 7
  Advanced <http://labs.hol.vmware.com/HOL/catalogs/catalog/123>`_

- `Official VMware vRealize Automation documentation
  <https://pubs.vmware.com/vra-70/index.jsp>`_
